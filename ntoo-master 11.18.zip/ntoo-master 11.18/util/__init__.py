import os
import psutil
import signal
import tempfile
import subprocess

TMP_DIR = tempfile.gettempdir()

# need to handle subprocesses differently on windows
WINDOWS = os.name == 'nt'


class ManagedProcess:
    def __init__(self, name):
        self._log_file = os.path.join(TMP_DIR, '{}.log'.format(name))
        self._pid_file = os.path.join(TMP_DIR, '{}.pid'.format(name))

    def start(self, cmd):
        """run a command and save log to a file"""
        if self.is_running:
            raise Exception('Process is already running.')

        with open(self._log_file, 'w+') as f:
            kwargs = {
                'stdout': f,
                'stderr': subprocess.STDOUT,
            }
            if WINDOWS:
                kwargs['creationflags'] = subprocess.CREATE_NEW_PROCESS_GROUP
            else:
                kwargs['preexec_fn'] = os.setsid
            ps = subprocess.Popen(cmd, **kwargs)
        with open(self._pid_file, 'w') as f:
            f.write(str(ps.pid))

    def stop(self):
        """kills running model process"""
        pid = self.pid
        if pid is None:
            return
        if WINDOWS:
            os.kill(pid, signal.CTRL_BREAK_EVENT)
        #else:
        #    os.killpg(os.getpgid(pid), signal.SIGTERM)  #or signal.SIGKILL
        #os.remove(self._pid_file)

    @property
    def pid(self):
        """gets pid of running model process"""
        try:
            return int(open(self._pid_file, 'r').read().strip())
        except FileNotFoundError:
            return None

    @property
    def logs(self):
        with open(self._log_file, 'r') as f:
            return f.read().strip().split('\n')

    @property
    def is_running(self):
        """check if the process is running by pid.
        assumes that the pid has successfully be written to the pid file."""
        pid = self.pid
        if pid is None:
            return False

        # <https://stackoverflow.com/a/568285>
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        else:
            proc = psutil.Process(pid)
            return proc.status() != psutil.STATUS_ZOMBIE
