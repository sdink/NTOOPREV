from flask_wtf import FlaskForm
from wtforms.fields import FloatField
from wtforms.validators import Required, NumberRange
from wtforms.fields.html5 import IntegerField
from chatbot.setup.settings import hparams


class TrainForm(FlaskForm):
    num_train_steps = IntegerField('Num. training steps', [Required(), NumberRange(min=0)], default=hparams['num_train_steps'])
    learning_rate = FloatField('Learning rate', [Required(), NumberRange(min=0)], default=hparams['learning_rate'])
