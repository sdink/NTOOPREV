from . import manager
from flask import Blueprint, jsonify

bp = Blueprint('api', __name__, url_prefix='/api')


@bp.route('/stop')
def stop():
    """stops training"""
    manager.proc.stop()
    return jsonify(success=True)


@bp.route('/status')
def status():
    """returns log info """
    running = manager.proc.is_running
    logs = manager.logs if running else []
    return jsonify(success=True, running=running, logs=logs)
