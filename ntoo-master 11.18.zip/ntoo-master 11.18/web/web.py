from . import manager
from .forms import TrainForm
from flask import Blueprint, render_template, redirect, url_for
from chatbot.prepare import prepare_data

bp = Blueprint('web', __name__)


@bp.route('/')
def index():
    return render_template('status.html')


@bp.route('/train', methods=['GET', 'POST'])
def train():
    form = TrainForm()
    if form.validate_on_submit():
        manager.start('train', config=form.data)
        return redirect(url_for('web.index'))
    return render_template('train.html', form=form)


@bp.route('/prepare', methods=['GET', 'POST'])
def prepare():
    n_examples = prepare_data()
    return render_template('prepare.html', n_examples=n_examples)
