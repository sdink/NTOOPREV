"""
Manages the model process.

This launches the model as a subprocess
and tracks it with a pidfile.
"""

import json
from util import ManagedProcess

proc = ManagedProcess('ntoo')

def start(type, **kwargs):
    """run the model as a subprocess,
    which makes it easier to manage"""
    if type not in ['train']:
        raise Exception('Unrecognized run type "{}".'.format(type))

    cmd = [
        'python',
        'ntoo.py',
        type,
        '-c', json.dumps(kwargs['config']),
    ]
    proc.start(cmd)
