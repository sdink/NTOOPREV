#!/bin/bash
# This will setup the necessary components for NTOO
# on an Ubuntu Linux or a MacOS machine

# TODO clone latest model (ideally as a compressed archive)

if [[ ! "$OSTYPE" =~ ^darwin ]]; then
    # Linux
    TENSORFLOW="tensorflow-gpu>=1.4.0"

    apt update
    apt install -y python3 python3-pip python3-setuptools wget

    # For MaryTTS
    apt install -y openjdk-8-jdk
else
    # MacOS
    TENSORFLOW="tensorflow>=1.4.0"

    brew update
    brew install -y python3 python3-pip python3-setuptools wget

    # For MaryTTS
    brew tap caskroom/versions
    brew cask install java8
fi

echo "Installing Python dependencies..."
cd chatbot
if ! [ -x "$(command -v conda)" ]; then
    pip3 install -r requirements.txt
    cat requirements.txt | xargs pip3 install
    pip3 install $TENSORFLOW
else
    conda install --yes --file requirements.txt
fi
cd ..

# MaryTTS
echo "Setting up MaryTTS..."
wget https://github.com/marytts/marytts/releases/download/v5.2/marytts-5.2.zip -O marytts.zip
unzip marytts.zip
mv marytts-5.2 marytts
rm marytts.zip

echo "Downloading NLP corpora..."
python3 -m textblob.download_corpora

echo "Preparing training data..."
python3 ntoo.py prepare_data