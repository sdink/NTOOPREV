import sys
import argparse
import colorama
import random
import tensorflow as tf
import speech_recognition as sr
from . import scoring, tts
from .nmt import nmt
from .setup import settings
from .core.tokenizer import tokenize, detokenize
from .core.sentence import score_answers, replace_in_answers
from textblob import TextBlob


def inference(phrase, infer_model, flags, hparams):
    infer_data = [phrase]
    with tf.Session(graph=infer_model.graph, config=nmt.utils.get_config_proto()) as sess:
        # Load model
        loaded_infer_model = nmt.inference.model_helper.load_model(infer_model.model, flags.ckpt, sess, "infer")

        # Run model (translate)
        sess.run(
            infer_model.iterator.initializer,
            feed_dict={
                infer_model.src_placeholder: infer_data,
                infer_model.batch_size_placeholder: hparams.infer_batch_size
            })

        # calculate number of translations to be returned
        num_translations_per_input = max(min(hparams.num_translations_per_input, hparams.beam_width), 1)
        translations = []

        try:
            nmt_outputs, _ = loaded_infer_model.decode(sess)
            if hparams.beam_width == 0:
                nmt_outputs = nmt.inference.nmt_model.np.expand_dims(nmt_outputs, 0)

            # Iterate through responses
            for beam_id in range(num_translations_per_input):

                if hparams.eos: tgt_eos = hparams.eos.encode("utf-8")

                # Select a sentence
                output = nmt_outputs[beam_id][0, :].tolist()

                # If there is an eos symbol in outputs, cut them at that point
                if tgt_eos and tgt_eos in output:
                    output = output[:output.index(tgt_eos)]

                # Format response
                if hparams.subword_option == "bpe":  # BPE
                    translation = nmt.utils.format_bpe_text(output)
                elif hparams.subword_option == "spm":  # SPM
                    translation = nmt.utils.format_spm_text(output)
                else:
                    translation = nmt.utils.format_text(output)

                # Add response to array
                translations.append(translation.decode('utf-8'))

        except tf.errors.OutOfRangeError:
            pass

        return translations


class Chatbot:
    def __init__(self):
        # Modified autorun from nmt.py (bottom of the file)
        # We want to use original argument parser (for validation, etc)
        nmt_parser = argparse.ArgumentParser()
        nmt.add_arguments(nmt_parser)
        # But we have to hack settings from our config in there instead of commandline options
        flags, unparsed = nmt_parser.parse_known_args(['--'+k+'='+str(v) for k,v in settings.hparams.items()])

        # Make hparams
        hparams = nmt.create_hparams(flags)

        ## Train / Decode
        if not tf.gfile.Exists(flags.out_dir):
            nmt.utils.print_out("# Model folder (out_dir) doesn't exist")
            sys.exit()

        # Load hparams from model folder
        hparams = nmt.create_or_load_hparams(flags.out_dir, hparams, flags.hparams_path, save_hparams=True)

        # Choose checkpoint (provided with hparams or last one)
        if not flags.ckpt:
            flags.ckpt = tf.train.latest_checkpoint(flags.out_dir)

        # Create model
        if not hparams.attention:
            model_creator = nmt.inference.nmt_model.Model
        elif hparams.attention_architecture == "standard":
            model_creator = nmt.inference.attention_model.AttentionModel
        elif hparams.attention_architecture in ["gnmt", "gnmt_v2"]:
            model_creator = nmt.inference.gnmt_model.GNMTModel
        else:
            raise ValueError("Unknown model architecture")
        infer_model = nmt.inference.model_helper.create_infer_model(model_creator, hparams, None)

        self.inference_object = infer_model, flags, hparams


    def inference(self, question):
        return inference(tokenize(question), *self.inference_object)

    def answer(self, question):
        answers = self.inference(question)
        answers = detokenize(answers)
        answers = replace_in_answers(answers, 'answers')
        answers_rate = score_answers(answers, 'answers')
        return answers, answers_rate


def talk(text_only=False):
    print("Starting interactive mode...")
    colorama.init()
    bot = Chatbot()
    tts.start_server()

    try:
        # QAs
        while True:
            if text_only:
                question = input("\n> ")
                if not question:
                    continue
            else:
                r = sr.Recognizer()
                with sr.Microphone() as source:
                    print("Speak:")
                    audio = r.listen(source, phrase_time_limit=2)

                try:
                    question = r.recognize_google(audio)
                    tb = TextBlob(question)
                    polarity = tb.sentiment.polarity
                    print("You said: " + question)
                    print("Sentiment polarity: " + str(polarity))
                except sr.UnknownValueError:
                    continue
                except sr.RequestError as e:
                    print("Could not request results; {0}".format(e))

            answers, answers_rate = bot.answer(question)
            ans_score = {}
            for i, answer in enumerate(answers):
                score = scoring.do_scoring(question, answer, answers_rate[i])
                print(answer, ':', score)
                ans_score[answer] = score

            scores = [v for k,v in ans_score.items()]
            max_score = max(scores)
            options = [k for k,v in ans_score.items() if v == max_score]
            answer = random.choice(options)
            print("{}- {}{}".format(colorama.Fore.GREEN, answer, colorama.Fore.RESET))

            # text to speech
            tts.say(answer)

            # Get keywords
            # noun, noun plural, proper noun, proper noun plural
            tb = TextBlob(answer)
            keywords = [t for t, tag in tb.tags if tag in ['NN', 'NNS', 'NNP', 'NNPS']]
            keywords.extend(tb.noun_phrases)

            yield question, answer, keywords
    except Exception:
        print('Shutting down MaryTTS server...')
        tts.stop_server()
        raise
