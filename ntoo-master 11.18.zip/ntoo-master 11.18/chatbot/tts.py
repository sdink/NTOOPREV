import os
import requests
from time import sleep
from util import ManagedProcess
import simpleaudio as sa

addr = 'http://localhost:59125/process'
proc = ManagedProcess('marytts')

def start_server():
    print('Starting MaryTTS server...')
    cwd = os.getcwd()
    os.chdir('marytts/bin')
    proc.start(['./marytts-server'])
    os.chdir(cwd)
    sleep(10)

def stop_server():
    proc.stop()

def say(text, play=True):
    # Visit http://localhost:59125
    # and use network requests inspector to
    # see other valid requests params
    resp = requests.get(addr, params={
        'INPUT_TYPE': 'TEXT',
        'AUDIO': 'WAVE_FILE',
        'AUDIO_OUT': 'WAVE_FILE',
        'OUTPUT_TYPE': 'AUDIO',
        'LOCALE': 'en_US',
        'INPUT_TEXT': text
    })
    audio = sa.play_buffer(resp.content, 1, 2, 48000)
    while audio.is_playing():
        continue
