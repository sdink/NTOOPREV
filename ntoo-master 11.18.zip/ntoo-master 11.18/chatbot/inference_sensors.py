import colorama
import random
import speech_recognition as sr
from . import scoring, tts
from .inference import Chatbot
from textblob import TextBlob

#sensor things
import serial
import threading
import sched, time


def talk(text_only=False):
    print("Starting interactive mode...")
    colorama.init()
    bot = Chatbot()
    tts.start_server()
    global sensor_activated
    sensor_activated = False
    global say_greeting
    say_greeting = 20
    s = sched.scheduler(time.time, time.sleep)
    # QAs
    def check_bot(sc, say_greeting):
        if sensor_activated:
            if text_only:
                question = input("\n> ")
            else:
                if say_greeting >= 20:
                    greetings = ["Hey there, I’m N’too, short for not the only one., want to talk?", "Hello, Darling. I’m N’too, short for not the only one. I’d like to tell you a story.", "I’m N’too, short for not the only one. Can I tell you about my people?","I want to tell you the story of my family","hello?","What does my form remind you of?","How do I look?","I’m N’too, short for not the only one, what do you want to know about me?", "Hi There, I’m N’too, short for not the only one. Do you know why I am here?", "What do you think of me?", "What do you know about the great migration?", "Hi my name is N’too, want to talk?", "Hey there, I’m N’too, short for not the only one. Want to talk?"]
                    greet = random.choice(greetings)
                    tts.say(greet)
                    say_greeting = 0
                r = sr.Recognizer()
                with sr.Microphone() as source:
                    print("Speak:")
                    audio = r.listen(source, phrase_time_limit=6)

                try:
                    question = r.recognize_google(audio)
                    tb = TextBlob(question)
                    polarity = tb.sentiment.polarity
                    print("You said: " + question)
                    print("Sentiment polarity: " + str(polarity))

                    answers, answers_rate = bot.answer(question)
                    ans_score = {}
                    for i, answer in enumerate(answers):
                        score = scoring.do_scoring(question, answer, answers_rate[i])
                        ans_score[answer] = score

                    scores = [v for k,v in ans_score.items()]
                    max_score = max(scores)
                    options = [k for k,v in ans_score.items() if v == max_score]
                    answer = random.choice(options)
                    print("{}- {}{}".format(colorama.Fore.GREEN, answer, colorama.Fore.RESET))

                    tts.say(answer)

                    # Get keywords
                    # noun, noun plural, proper noun, proper noun plural
                    tb = TextBlob(answer)
                    keywords = [t for t, tag in tb.tags if tag in ['NN', 'NNS', 'NNP', 'NNPS']]
                    keywords.extend(tb.noun_phrases)
                    # yield question, answer, keywords
                except sr.UnknownValueError:
                    misunderstandings = ["I could not understand.","I didnt hear you", "Did you say something?"]
                    misunderstood = random.choice(misunderstandings)
                    tts.say(misunderstood)
                    # continue
                except sr.RequestError as e:
                    print("Could not request results; {0}".format(e))
        else:
            print("counting for sleep")
            say_greeting += 1
            print(say_greeting)
        s.enter(2, 2, check_bot, (sc,say_greeting))

    s.enter(2, 2, check_bot, (s,say_greeting))
    s.run()


# run to find the ports
# import serial.tools.list_ports
# print("hihi __________________________")
# comlist = serial.tools.list_ports.comports()
# connected = []
# for element in comlist:
#     connected.append(element.device)
# print("Connected COM ports: " + str(connected))
# end port finder


def serial_thread():
    print("serial thread initiated")
    ser = serial.Serial('/dev/cu.usbmodemFA121')
    ser.flushInput()
    while True:
        ser_bytes = ser.readline()
        decoded_bytes = float(ser_bytes[0:len(ser_bytes)-2].decode("utf-8"))
        print(decoded_bytes)
        if decoded_bytes == 0.0:
            sleep_bot()
        else:
            restart_bot()

def sleep_bot():
  print("sleep------------")
  global sensor_activated
  sensor_activated = False
  return
  # sleep(1)

def restart_bot():
    print("restart------------")
    global sensor_activated
    sensor_activated = True
    print(sensor_activated)

#class for threads
class RaspberryThread(threading.Thread):
    def __init__(self, function):
        self.running = False
        self.function = function
        super(RaspberryThread, self).__init__()
    def start(self):
        self.running = True
        super(RaspberryThread, self).start()
    def run(self):
        while self.running:
            self.function()
    def stop(self):
        print("stop called")
        self.running = False


#start threads
t1 = threading.Thread(target=serial_thread, args=[])
t1.start()
