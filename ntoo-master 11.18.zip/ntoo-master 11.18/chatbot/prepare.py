"""
Converts JSON interview data into training data for the model.
"""

import os
import re
import json
import pandas as pd
from glob import glob
from tqdm import tqdm
from collections import Counter
from chatbot.core.tokenizer import tokenize
from chatbot.core.sentence import replace_in_answers
from chatbot.setup.settings import preprocessing as conf
from chatbot.setup.settings import hparams

def openf(dir, file, mode):
    return open('{}/{}'.format(dir, file), mode, encoding='utf-8')

def prepare_data(include_conversations=True, extend_existing_vocab=True):
    train_log_dir = os.path.join(hparams['out_dir'], 'train_log')

    print('Loading interviews...')
    files = glob('interviews/*.csv')
    questions, answers = [], []
    curr_q = None
    curr_as = []
    for f in files:
        df = pd.read_csv(f)
        for row in df.itertuples():
            if row.role == 'Q':
                for a in curr_as:
                    questions.append({'Transcript': curr_q})
                    answers.append({'Transcript': a})
                curr_q = row.transcript
                curr_as = []
            if row.role == 'A':
                curr_as.append(row.transcript)

    if include_conversations:
        convo_path = 'conversations.log'
        if os.path.exists(convo_path):
            convos = open(convo_path, 'r')
            for line in convos:
                data = json.loads(line)
                questions.append({'Transcript': data['Q']})
                answers.append({'Transcript': data['A']})

    if not os.path.exists(train_log_dir):
        os.makedirs(train_log_dir)

    # Check propery question-answer alignment
    assert len(questions) == len(answers)

    data = {
        'from': {
            'lines': [],
            'vocab': []
        },
        'to': {
            'lines': [],
            'vocab': []
        }
    }

    print('Preparing questions...')
    for q in tqdm(questions):
        text = q['Transcript']
        if not isinstance(text, str):
            continue
        # Clean up questions
        text = re.sub(r'^[ *]+', '', text)
        toks = tokenize(text)
        data['from']['lines'].append(toks)
        data['from']['vocab'].extend(toks.split())

    print('Preparing answers...')
    for a in tqdm(answers):
        text = a['Transcript']
        if not isinstance(text, str):
            continue
        toks = tokenize(text)
        data['to']['lines'].append(toks)
        data['to']['vocab'].extend(toks.split())

    print('Preparing training data and vocab...')
    for k, d in data.items():
        for fn in ['train', 'tst2012', 'tst2013']:
            with openf(conf['train_folder'], '{}.{}'.format(fn, k), 'w') as f:
                f.write('\n'.join(d['lines']))

        vocab = Counter(d['vocab'])
        vocab = [entity for entity, v in vocab.most_common()]
        new_vocab = [replace_in_answers([entity], 'vocab')[0] for entity in vocab]

        # Filter out duplicates and empty entities
        vocab = set()
        vocab = [entity for entity in new_vocab if not (entity in vocab or vocab.add(entity)) and entity]

        # Pad vocab with empty terms
        size = conf['vocab_size']

        if extend_existing_vocab:
            try:
                with openf(conf['train_folder'], 'vocab.{}'.format(k), 'r') as f:
                    keep_vocab = [t.strip() for t in f.readlines()]
                    keep_vocab = [t for t in keep_vocab if not t.startswith('<_')]
            except FileNotFoundError:
                keep_vocab = []
        else:
            keep_vocab = []

        if not keep_vocab:
            keep_vocab = ['<unk>', '<s>', '</s>']

        for t in vocab:
            if t not in keep_vocab:
                keep_vocab.append(t)
            if len(keep_vocab) >= size:
                break

        if extend_existing_vocab:
            # Pad vocab so we can extend it without needing to re-train the model
            keep_vocab.extend('<_{}>'.format(i) for i in range(size - len(keep_vocab)))

        # Write entities to a file
        with openf(conf['train_folder'], 'vocab.{}'.format(k), 'w') as f:
            f.write('\n'.join(keep_vocab))
        with openf(conf['train_folder'], 'vocab_unused.{}'.format(k), 'w') as f:
            f.write('\n'.join(vocab[size:]))

        # Write metadata for embeddings
        tsv = 'decoder.tsv' if k == 'to' else 'encoder.tsv'
        with openf(train_log_dir, tsv, 'w') as f:
            f.write('<unk>\n<s>\n</s>\n' + '\n'.join(vocab[:conf['vocab_size']]))

        # Write pbtxt file for metadata for embeddings
        with openf(train_log_dir, 'projector_config.pbtxt', 'w') as f:
            f.write('''embeddings {\n    tensor_name: 'embeddings/decoder/embedding_decoder'\n    '''+
                    '''metadata_path: 'decoder.tsv'\n}\nembeddings {\n    '''+
                    '''tensor_name: 'embeddings/encoder/embedding_encoder'\n    metadata_path: 'encoder.tsv'\n}''')
    print('Done')

    return len(questions)
