## Installation & setup (Debian/Ubuntu)

Run `./setup.sh`. This will install the system and Python dependencies and prepare the training data.

```
sh setup.sh
```

## Loading data from CSVs

To generate training data from CSV interview files found in the `interviews` folder, run:

```
python ntoo.py prepare_data
```

To include conversation logs (if available):

```
python ntoo.py prepare_data --include-convos
```

## Interactive mode

To run the interactive mode, run:

```
python ntoo.py talk
```

To use text input rather than voice, you can use the `--text-only` flag:

```
python ntoo.py talk --text-only
```

For the interactive mode that uses the sensors:

```
python ntoo.py sensor_talk
```

## Web interface

A web interface is available to manage model training:

```
python ntoo.py web
```

Then visit `localhost:8000`.

## Creating a new voice

See the `voicebuilder` folder
