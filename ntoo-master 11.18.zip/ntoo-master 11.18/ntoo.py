import os
import json
import click
import argparse
import tensorflow as tf
from chatbot.nmt import nmt
from chatbot import inference, prepare
from chatbot.setup.settings import hparams, preprocessing
from web import app


@click.group()
@click.option('-m', '--model', help='Name of model to use')
def main(model):
    if model is not None:
        out_dir = os.path.join('chatbot/models', model)
        train_dir = os.path.join('chatbot/models', model, 'data')

        hparams['out_dir'] = out_dir
        preprocessing['train_folder'] = train_dir
        hparams['vocab_prefix'] = os.path.join(train_dir, 'vocab')
        hparams['train_prefix'] = os.path.join(train_dir, 'train')
        hparams['dev_prefix'] = os.path.join(train_dir, 'tst2012')
        hparams['test_prefix'] = os.path.join(train_dir, 'tst2013')

        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        if not os.path.exists(train_dir):
            os.makedirs(train_dir)


@main.command()
@click.option('-c', '--config', help='JSON of run config override')
def train(config):
    """Train the model."""
    config = json.loads(config) if config is not None else {}
    hparams.update(config)

    # Modified autorun from nmt.py (bottom of the file)
    # We want to use original argument parser (for validation, etc)
    nmt_parser = argparse.ArgumentParser()
    nmt.add_arguments(nmt_parser)
    # But we have to hack settings from our config in there instead of commandline options
    nmt.FLAGS, unparsed = nmt_parser.parse_known_args(['--'+k+'='+str(v) for k,v in hparams.items()])
    # And now we can run TF with modified arguments
    tf.app.run(main=nmt.main, argv=[os.getcwd() + '\nmt\nmt\nmt.py'] + unparsed)


@main.command()
@click.option('--text-only', is_flag=True, help='Text input')
@click.option('--save-convos', is_flag=True, help='Save conversations')
def talk(text_only, save_convos):
    """Run interactive talking process.
    Saves conversations to a log for further training."""
    for question, answer, keywords in inference.talk(text_only=text_only):
        print('Keywords:', keywords)
        if save_convos:
            with open('conversations.log', 'a') as f:
                f.write(json.dumps({'Q': question, 'A': answer})+'\n')


@main.command()
def sensor_talk():
    from chatbot.inference_sensors import talk
    talk()


@main.command()
@click.option('--include-convos', is_flag=True, help='Include conversations')
@click.option('--extend-vocab', is_flag=True, help='Pad/extend existing vocab')
def prepare_data(include_convos, extend_vocab):
    """Prepare training data from interviews and conversations"""
    prepare.prepare_data(include_conversations=include_convos, extend_existing_vocab=extend_vocab)


@main.command()
def web():
    app.run(port=8000, debug=True)


if __name__ == '__main__':
    main()
