#!/bin/bash

# Exit on any command failure
set -e

# Keep track of last-executed command
# so we know where to pick up if something breaks
trap 'last_cmd=$this_cmd; this_cmd=$BASH_COMMAND' DEBUG
trap 'echo "exit $? due to \"$last_cmd\""' EXIT

# Prepare config
DIR=$(pwd)
VOICEDIR=$(readlink --canonicalize $1)
VOICENAME=$(basename $VOICEDIR)
sed 's|VOICEDIR|'${VOICEDIR}'|g' configs/database.config.template > $VOICEDIR/database.config
sed -i 's|DIR|'$(pwd)'|g' $VOICEDIR/database.config
sed -i 's|VOICENAME|'${VOICENAME}'|g' $VOICEDIR/database.config

# Refer to <https://github.com/marytts/marytts/wiki/HMMVoiceCreation#stepIII>
# for configuration details
cd $VOICEDIR
IMPORTER=$DIR/../marytts/builder/bin/voiceimport.sh
$IMPORTER Festvox2MaryTranscripts
$IMPORTER AllophonesExtractor
$IMPORTER EHMMLabeler
$IMPORTER LabelPauseDeleter
$IMPORTER PhoneUnitLabelComputer
$IMPORTER TranscriptionAligner
$IMPORTER FeatureSelection
$IMPORTER PhoneUnitFeatureComputer
$IMPORTER PhoneLabelFeatureAligner
$IMPORTER HMMVoiceDataPreparation
$IMPORTER HMMVoiceConfigure
$IMPORTER HMMVoiceFeatureSelection
$IMPORTER HMMVoiceMakeData

# Errors with this command,
# so executing the perl script directly
# as recommended in the instructions
# $IMPORTER HMMVoiceMakeVoice
perl hts/scripts/Training.pl hts/scripts/Config.pm
$IMPORTER HMMVoiceCompiler

# Install the new voice
cd mary/voice-*
cp target/voice-*-component.xml $DIR/../marytts/installed/
cp target/voice-*5.2.jar $DIR/../marytts/lib/
