(requires MaryTTS 5.2 and Ubuntu)

## Setup

To download and install all dependencies just run:

```
./setup.sh
```

## Creating a new voice

_(This process can take several hours)_

### Data preparation

__What you need__:

- A set of `wav` recordings, each a recording of the speaker saying one sentence
- A text document with transcriptions of each recording, with the associated recording file's name, in the following format `( filename "transcription" )`, one per line. For example:

```
( arctic_a0001 "Author of the danger trail, Philip Steels, etc." )
( arctic_a0002 "Not at this particular case, Tom, apologized Whittemore." )
```

Which would match recordings named `arctic_a0001.wav` and `artic_a0002.wav`.

Create a folder in the `voices` directory, e.g. `myvoice`, to store these files (the rest of the instructions assume the voice directory is `myvoice`).

The `wav` files go into `voices/myvoice/wav`, and the transcription file should be a file called `voices/myvoice/txt.done.data`.

### Building the voice

Run the MaryTTS server in a separate window:

```
../marytts/bin/marytts-server
```

Then run the build script in this directory, specifying the name of your voice directory:

```
./build.sh voices/myvoice
```

There'll be two dialog windows that open, just select "Save" for both of them.

This can take several hours.

## References

- <https://github.com/marytts/marytts/wiki/VoiceImportToolsTutorial>
- <https://github.com/marytts/marytts/wiki/HMMVoiceCreation>
- <http://www.coli.uni-saarland.de/~steiner/teaching/2016/winter/voicebuilding/slides/index.html#/prepare-for-hts-voicebuilding>
- <https://github.com/marytts/marytts/wiki/Publishing-a-MARY-TTS-Voice>
