#!/bin/bash
# Note: this only works on Linux

# Install dependencies listed here:
# <https://github.com/marytts/marytts/wiki/VoiceImportToolsTutorial>
sudo apt install -y praat speech-tools
sudo apt install -y sox bc tcl tcl-snack htsengine

# Build dependencies
sudo apt install -y libestools-dev libx11-dev
sudo apt install -y maven --no-install-recommends

DIR=$(pwd)
cd /tmp

wget http://downloads.sourceforge.net/hts-engine/hts_engine_API-1.05.tar.gz
tar -xzvf hts_engine*.tar.gz
cd hts_engine*
./configure --prefix=$DIR/deps/hts
make
make install

# Build HTK binaries
wget http://hts.sp.nitech.ac.jp/archives/2.2/HTS-2.2_for_HTK-3.4.1.tar.bz2
wget --user ftseng --password MNpcrhsu http://htk.eng.cam.ac.uk/ftp/software/HTK-3.4.1.tar.gz
wget --user ftseng --password MNpcrhsu http://htk.eng.cam.ac.uk/ftp/software/hdecode/HDecode-3.4.1.tar.gz

tar -xzvf HTK-*.tar.gz
tar -xzvf HDecode-*.tar.gz
tar -xjvf HTS-*.tar.bz2
cd htk
mkdir $DIR/deps/htk
patch -p1 -d . < ../HTS-2.2_for_HTK-3.4.1.patch
./configure --prefix=$DIR/deps/htk
make
make install

# Build SPTK binaries
wget http://downloads.sourceforge.net/sp-tk/SPTK-3.4.1.tar.gz
tar -xzvf SPTK-*.tar.gz
cd SPTK-*
./configure --prefix=$DIR/deps/sptk
make
make install

# Get MaryTTS source
# for EHMM biinaries, HTS sources,
# and to install with Maven
wget https://github.com/marytts/marytts/archive/v5.2.zip
unzip v5.2.zip
cd marytts-5.2
mvn install

# Copy over EHMM binaries and HTS sources
mkdir $DIR/../marytts/lib/external
cd lib/external/ehmm
make
mkdir $DIR/deps/ehmm
cp -r bin $DIR/deps/ehmm/bin
cd ..
cp -r hts $DIR/../marytts/lib/external/hts

# Create external binary config so the builder
# knows where to find the necessary probrams
cd $DIR
sed 's|DIR|'$(pwd)'|g' configs/externalBinaries.config.template > ../marytts/lib/external/externalBinaries.config

# For reference, not necessary
# export PATH=$PATH:deps/ehmm:deps/sptk/bin:deps/htk/bin
